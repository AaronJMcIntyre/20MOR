﻿using UnityEngine;
using System.Collections;

public class DamagePlayer : MonoBehaviour {

    public float damage = 5f;
    //sets damage output


    void OnCollision2DEnter(Collision2D coll)
    {
        if (coll.gameObject.tag == "Spike")
        {
            //Accesses the PlayerHealth script when a collision occurs with the object it is attached too.
            this.GetComponent<PlayerHealth>().m_CurrentHealth -= 1;
                }
    }
	// Use this for initialization
	void Start () {
        
    }
	// Update is called once per frame
	void Update () {
	
	}
}
