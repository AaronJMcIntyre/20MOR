﻿using UnityEngine;
using System.Collections;

public class PlayerHealth : MonoBehaviour
{
    // accesses player object
    public GameObject player;


    // sets up player health
    public float m_StrartingHealth = 20;

    // sets up players current health
    public float m_CurrentHealth;







   

    // Update is called once per frame
    private void OnEnable()
    {

        m_CurrentHealth = m_StrartingHealth;
        // makes current health and starting health the same. 


        if (m_CurrentHealth == 0)
        {
            Destroy(gameObject, 2f);
            // destroys player if health hits zero
        }

    }



    void OnCollisionEnter2D(Collision2D coll)
    {

        if (coll.gameObject.tag == "Fall")
        {
            m_CurrentHealth -= 10;

            if (m_CurrentHealth == 0)
            {
                gameObject.SetActive(false);//Destroy(gameObject, 2f);
                // kills player if falling off stage
            } 
        }

        if (coll.gameObject.tag == "Spike")
        {
            m_CurrentHealth -= 10;

            if (m_CurrentHealth == 0)
            {
                gameObject.SetActive(false);
                // does damage to player if spike if hit
            }


        }

        if (coll.gameObject.tag == "Enemy")
        {
            m_CurrentHealth -= 5;

            if (m_CurrentHealth == 0)
            {
                gameObject.SetActive(false);
                // damages player if hit by enemy
            }
        }


    }

 

}
    
