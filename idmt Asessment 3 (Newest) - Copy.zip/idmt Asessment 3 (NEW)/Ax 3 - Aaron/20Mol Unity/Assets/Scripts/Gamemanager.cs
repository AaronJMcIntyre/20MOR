﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Gamemanager : MonoBehaviour
{
    public Text MessageText;

    public GameObject Player;
    public GameObject Win;
    bool isGameOver = false;
    public enum GameState
    {//sets up gamestates
        Start,
        Playing,
        GameOver

    };

    private GameState m_GameState;
    public GameState Sate { get { return m_GameState; } }

    //sets up a gamestate variable

    private void Awake()
    {//Access' gamestate to begin game on load
        m_GameState = GameState.Start;

    }

    private void Start()
    {//makes player inactive at start of game
        Player.SetActive(false);
        
        //displayes get ready message
        MessageText.text = "Get Ready";

    }
    void Update()
    {
        switch (m_GameState)
        {//switches gamestate to start
            case GameState.Start:




               


                if (Input.GetKeyUp(KeyCode.Return) == true)
                {
                    // if key is pushed (enter) begines Playing state


                    MessageText.text = "";

                    m_GameState = GameState.Playing;

                   Player.SetActive(true);
                }

                break;
            case GameState.Playing:
                


              if (IsPlayerDead() == true)
                {//if player is dead, Gameover state initiated
                    isGameOver = true;
                }



                if (isGameOver == true)
                {
                    m_GameState = GameState.GameOver;

                    if (IsPlayerDead() == true)
                    {
                        MessageText.text = "TRY AGAIN";
                    }
                    //if game is over and player is dead, "Try Again" text displayed
                    else
                    {
                        MessageText.text = "WINNER!";
                    }
                    //If player has reached end point alive "Winner" text is displayed

                }
                break;

            case GameState.GameOver:
                if(Input.GetKeyUp(KeyCode.Return)  == true)
                {
                    m_GameState = GameState.Playing;
                    isGameOver = false;
                    MessageText.text = "";

                    Player.SetActive(true);


                }
                break;
                //When player is dead we can press "enter" to start again

        }

        if (Input.GetKeyUp(KeyCode.Escape))
        {
            Application.Quit();
        }
        //if escape key is hit, quits game

    }

    
       
    public void PlayerWin()
    {
        isGameOver = true;
    }
       //If player has reached end point gameover is deamed true 
        
    

    private bool IsPlayerDead()
    {
        if (Player.activeSelf == false)
        {
            return true;
        }
        return false;
    }
    //Deactivtes player on death



}