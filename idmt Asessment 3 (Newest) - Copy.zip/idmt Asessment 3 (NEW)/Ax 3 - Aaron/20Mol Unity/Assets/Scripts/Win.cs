﻿using UnityEngine;
using System.Collections;

public class Win : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}


    void OnTriggerEnter2D(Collider2D Win)
        //Whn player collides with object this script is attached too. "Win" function is run in Gamemanger script.
    {
        if (Win.tag == "Player") //Locates tag on object to see if it is the player or not.
        {
            FindObjectOfType<Gamemanager>().PlayerWin();
            //accesses the gamemanager
        }
    }



}
