﻿using UnityEngine;
using System.Collections;

public class EnemyMovement : MonoBehaviour {

    public Transform Target;
    private GameObject Player;
    private float Range;
    public float Speed = 0.5f;
    private bool playerisinRange;

    private Gamemanager gm;
    
    public bool facingRight = true;
    

    // Use this for initialization
    void Start() {
        //at the beginning of the game the Gamemanager script is located
        gm = FindObjectOfType<Gamemanager>();

    }

    // Update is called once per frame
    void Update() {

        Player = gm.Player;
        //allows enemy to track player

        Range = Vector2.Distance(transform.position, Player.transform.position);
        if (playerisinRange)
        {
            float h = Player.transform.position.x - transform.position.x;

            if (h > 0 && !facingRight)
                Flip();
            else if (h < 0 && facingRight)
                Flip();

            //transform.LookAt(Target);

            //if in range moves enemy towards target (player)
            transform.position = Vector2.MoveTowards(transform.position, Player.transform.position, Speed * Time.deltaTime) ;
        }
        
    }

    void Flip()
    {
        //Flips the sprite to face the player
        facingRight = !facingRight;
        SpriteRenderer SR = GetComponent<SpriteRenderer>();
        SR.flipX = facingRight;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        //checks to see if player is within range to move towards it.
        if (other.gameObject == Player)
        {
            
            playerisinRange = true;
        }
    }
    void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject == Player)
        {
            playerisinRange = false;
        }
    }
}
